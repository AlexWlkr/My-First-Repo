## Starter and solution code for Coding Responsive Websites, Lesson 4, Step 2.
